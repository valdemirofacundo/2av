<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pw";

// Criar a conexão com o banco de dados:
$conn = mysqli_connect($servername,$username,$password,$dbname);
