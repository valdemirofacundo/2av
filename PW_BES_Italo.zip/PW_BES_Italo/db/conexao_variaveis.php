<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pw";
