<?php
//echo('Alô mundo! 2024!');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pw";

// Criar a conexão com o banco de dados:
$conn = mysqli_connect($servername,$username,$password,$dbname);


// Selecionar registros da tabela pessoa:
$sql = "SELECT * FROM pessoa";
$result = mysqli_query($conn, $sql);

// Exibir registros da tabela pessoa:
while($row = mysqli_fetch_assoc($result)) {
	echo($row["cod_cpf"]." ".$row["nom_pessoa"]."<br>");
}
?>