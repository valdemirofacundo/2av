function Exibir(valor) {
    lbExibir.textContent = valor;
}
function validaBusca() {
    if (document.querySelector('#q').value == '') {
    document.querySelector('#form-busca').style.background = 'red';
    alert('Digite algo para pesquisar!');
    //document.querySelector('#form-busca').style.border = 'red 2px';
//    document.querySelector('#form-busca').style.border_width = '2px';

    return false;
    }
}
//confirm('Alô mundo!');
/*
if (confirm('Sim ou não?')) {
    alert('Sim!');
}
else {
    alert('Não!');
}
 */


document.querySelector("input[type=email]").oninvalid = function() {
    alert('Teste');
    // remove mensagens de erro antigas
    this.setCustomValidity("");

    // reexecuta validação
    if (!this.validity.valid) { 
        // se inválido, coloca mensagem de erro
        this.setCustomValidity("Email inválido......");
    }
};
