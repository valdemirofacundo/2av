<!DOCTYPE html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pw";

// Criar a conexão com o banco de dados:
$conn = mysqli_connect($servername,$username,$password,$dbname);


// Selecionar registros da tabela pessoa:
$sql = "SELECT * FROM bandeira";
$result = mysqli_query($conn, $sql);
?>
<html>
    <head>
        <title>Checkout Mirror Fashion</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <style>
            .form-control:invalid { 
                border: 1px solid #cc0000; 
            }
        </style>
    </head>

    <body>
        <div class="jumbotron">
            <div class="container">
                <h1>Ótima escolha!</h1>
                <p>Obrigado por comprar na Mirror Fashion! Preencha seus dados para efetivar a compra.</p>
            </div>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2 class="panel-title">Sua compra</h2>
                        </div>

                        <div class="panel-body">
                            <img src="img/produtos/foto1-verde.png" alt="Fuzzy Cardigan" 
                                class="img-thumbnail img-responsive hidden-xs">
                            <dl>
                                <dt>Produto</dt>
                                <dd>Fuzzy Cardigan</dd>

                                <dt>Cor</dt>
                                <dd>verde</dd>

                                <dt>Tamanho</dt>
                                <dd>40</dd>

                                <dt>Preço</dt>
                                <dd>R$ 129,00</dd>
                            </dl>
                        </div>
                    </div>
                </div>
        
                <!-- Formulário: -->
                <form name="form1" id="form1" class="col-sm-8 col-lg-9">
                    <fieldset class="col-md-6">
                        <legend>Dados pessoais</legend>
                        <div class="form-group">
                            <label for="nome">Nome completo</label>
                            <input type="text" class="form-control" id="nome" name="nome"
                                   autofocus required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <div class="input-group">
                                <span class="input-group-addon">@</span>
                                <input type="email" class="form-control" id="email" name="email"
                                       placeholder="email@exemplo.com"> 
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="cpf">CPF</label>
                            <input type="text" class="form-control" id="cpf" name="cpf"
                                   placeholder="000.000.000-00" required>
                        </div>
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" value="sim" name="spam" checked>Quero receber spam da Mirror Fashion 
                            </label>
                        </div>
                    </fieldset>
                    <fieldset class="col-md-6">
                        <legend>Cartão de crédito</legend>
                        <div class="form-group">
                            <label for="numero-cartao">Número - CVV</label>
                            <input type="text" class="form-control" id="numero-cartao" name="numero-cartao">
                        </div>
                        <div class="form-group">
                            <label for="bandeira-cartao">Bandeira</label>
                            <select name="bandeira-cartao" id="bandeira-cartao" class="form-control">
                                <?php
// Exibir registros da tabela bandeira:
                                while($row = mysqli_fetch_assoc($result)) {
                                ?>
                                    <option value="<?=$row["cod_bandeira"]?>"><?=$row["nom_bandeira"]?></option>
                                <?php
                                }
                                ?>
<!--
                                <option value="master">MasterCard</option>
                                <option value="visa">VISA</option>
                                <option value="amex">American Express</option>
-->
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="validade-cartao">Validade</label>
                            <input type="month" class="form-control" id="validade-cartao" name="validade-cartao">
                        </div>
                    </fieldset>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <span class="glyphicon glyphicon-thumbs-up"></span>
                        Confirmar Pedido 
                    </button>
                </form>
            </div>
        </div>
    </body>
    <script language="javascript">
        /*
        function validar() {
            //alert(document.querySelector("input[name='nome']").value);
            return true;
        }
         */
        document.querySelector("input[type=email]").oninvalid = function() {
            // remove mensagens de erro antigas
            this.setCustomValidity("");

            // reexecuta validação
            if (!this.validity.valid) { 
                // se inválido, coloca mensagem de erro
                this.setCustomValidity("Email inválido!");
            }
        };
    </script>
</html>
